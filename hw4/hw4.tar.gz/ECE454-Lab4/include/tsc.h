#ifndef TSC_H
#define TSC_H
extern void start_counter();
extern u_int64_t get_counter();
#endif
