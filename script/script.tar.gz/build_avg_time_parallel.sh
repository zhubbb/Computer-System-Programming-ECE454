#!/bin/bash
echo "Running..."
t=0 
p=$1
#no space when assign
for i in {1..5}
do
	echo "Compilation time: $i"
	make clean 1>/dev/null
        #p=$((2**(($i-1)*2)))
	
	t=`echo $( TIMEFORMAT='%E';time  ( make -j $p )  2>&1 1>/dev/null )+$t | bc`

done
sleep 1
t=$(($t/5))
echo "The average compilation time is $t seconds."
